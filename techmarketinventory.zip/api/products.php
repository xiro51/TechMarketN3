<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

$auth = new Auth();
$auth->requireLogin();

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $products = $db->getProducts();
        echo json_encode($products);
        break;
        
    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $product = $db->createProduct(
            $data['name'],
            $data['category'],
            $data['quantity'],
            $data['price']
        );
        echo json_encode($product);
        break;
        
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $product = $db->updateProduct($data['id'], $data);
        echo json_encode($product);
        break;
        
    case 'DELETE':
        $data = json_decode(file_get_contents('php://input'), true);
        $success = $db->deleteProduct($data['id']);
        echo json_encode(['success' => $success]);
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}
?>
