<?php
require_once __DIR__ . '/../config/auth.php';

$auth = new Auth();
$auth->logout();

header('Content-Type: application/json');
echo json_encode(['success' => true]);
?>
