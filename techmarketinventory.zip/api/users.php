<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

$auth = new Auth();
$auth->requireAdmin();

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $users = $db->getUsers();
        // Remove passwords from response
        $users = array_map(function($user) {
            unset($user['password']);
            return $user;
        }, $users);
        echo json_encode($users);
        break;
        
    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Check if username exists
        if ($db->getUserByUsername($data['username'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Username already exists']);
            exit;
        }
        
        $user = $db->createUser(
            $data['username'],
            $data['password'],
            $data['role']
        );
        unset($user['password']);
        echo json_encode($user);
        break;
        
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $user = $db->updateUser($data['id'], $data);
        if ($user) {
            unset($user['password']);
        }
        echo json_encode($user);
        break;
        
    case 'DELETE':
        $data = json_decode(file_get_contents('php://input'), true);
        $success = $db->deleteUser($data['id']);
        echo json_encode(['success' => $success]);
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}
?>
