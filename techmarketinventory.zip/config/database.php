<?php
// Database configuration using JSON files for storage
class Database {
    private $usersFile = __DIR__ . '/../data/users.json';
    private $productsFile = __DIR__ . '/../data/products.json';
    
    public function __construct() {
        // Create data directory if it doesn't exist
        $dataDir = __DIR__ . '/../data';
        if (!file_exists($dataDir)) {
            mkdir($dataDir, 0777, true);
        }
        
        // Initialize files if they don't exist
        $this->initializeFiles();
    }
    
    private function initializeFiles() {
        // Initialize users file with default users
        if (!file_exists($this->usersFile)) {
            $defaultUsers = [
                [
                    'id' => '1',
                    'username' => 'admin',
                    'password' => password_hash('admin123', PASSWORD_DEFAULT),
                    'role' => 'Admin',
                    'createdAt' => date('c')
                ],
                [
                    'id' => '2',
                    'username' => 'user',
                    'password' => password_hash('user123', PASSWORD_DEFAULT),
                    'role' => 'User',
                    'createdAt' => date('c')
                ]
            ];
            file_put_contents($this->usersFile, json_encode($defaultUsers, JSON_PRETTY_PRINT));
        }
        
        // Initialize products file
        if (!file_exists($this->productsFile)) {
            file_put_contents($this->productsFile, json_encode([], JSON_PRETTY_PRINT));
        }
    }
    
    // User operations
    public function getUsers() {
        $data = file_get_contents($this->usersFile);
        return json_decode($data, true);
    }
    
    public function getUserById($id) {
        $users = $this->getUsers();
        foreach ($users as $user) {
            if ($user['id'] === $id) {
                return $user;
            }
        }
        return null;
    }
    
    public function getUserByUsername($username) {
        $users = $this->getUsers();
        foreach ($users as $user) {
            if ($user['username'] === $username) {
                return $user;
            }
        }
        return null;
    }
    
    public function createUser($username, $password, $role) {
        $users = $this->getUsers();
        $newUser = [
            'id' => (string)time(),
            'username' => $username,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role' => $role,
            'createdAt' => date('c')
        ];
        $users[] = $newUser;
        file_put_contents($this->usersFile, json_encode($users, JSON_PRETTY_PRINT));
        return $newUser;
    }
    
    public function updateUser($id, $updates) {
        $users = $this->getUsers();
        foreach ($users as &$user) {
            if ($user['id'] === $id) {
                if (isset($updates['password'])) {
                    $user['password'] = password_hash($updates['password'], PASSWORD_DEFAULT);
                }
                if (isset($updates['role'])) {
                    $user['role'] = $updates['role'];
                }
                file_put_contents($this->usersFile, json_encode($users, JSON_PRETTY_PRINT));
                return $user;
            }
        }
        return null;
    }
    
    public function deleteUser($id) {
        $users = $this->getUsers();
        $filtered = array_filter($users, function($user) use ($id) {
            return $user['id'] !== $id;
        });
        file_put_contents($this->usersFile, json_encode(array_values($filtered), JSON_PRETTY_PRINT));
        return count($filtered) < count($users);
    }
    
    // Product operations
    public function getProducts() {
        $data = file_get_contents($this->productsFile);
        return json_decode($data, true);
    }
    
    public function getProductById($id) {
        $products = $this->getProducts();
        foreach ($products as $product) {
            if ($product['id'] === $id) {
                return $product;
            }
        }
        return null;
    }
    
    public function createProduct($name, $category, $quantity, $price) {
        $products = $this->getProducts();
        $newProduct = [
            'id' => (string)time(),
            'name' => $name,
            'category' => $category,
            'quantity' => (int)$quantity,
            'price' => (float)$price,
            'createdAt' => date('c'),
            'updatedAt' => date('c')
        ];
        $products[] = $newProduct;
        file_put_contents($this->productsFile, json_encode($products, JSON_PRETTY_PRINT));
        return $newProduct;
    }
    
    public function updateProduct($id, $updates) {
        $products = $this->getProducts();
        foreach ($products as &$product) {
            if ($product['id'] === $id) {
                if (isset($updates['name'])) $product['name'] = $updates['name'];
                if (isset($updates['category'])) $product['category'] = $updates['category'];
                if (isset($updates['quantity'])) $product['quantity'] = (int)$updates['quantity'];
                if (isset($updates['price'])) $product['price'] = (float)$updates['price'];
                $product['updatedAt'] = date('c');
                file_put_contents($this->productsFile, json_encode($products, JSON_PRETTY_PRINT));
                return $product;
            }
        }
        return null;
    }
    
    public function deleteProduct($id) {
        $products = $this->getProducts();
        $filtered = array_filter($products, function($product) use ($id) {
            return $product['id'] !== $id;
        });
        file_put_contents($this->productsFile, json_encode(array_values($filtered), JSON_PRETTY_PRINT));
        return count($filtered) < count($products);
    }
}
?>
