"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

export type Currency = {
  code: string
  symbol: string
  name: string
  rate: number // Exchange rate relative to USD
}

export const currencies: Currency[] = [
  { code: "USD", symbol: "$", name: "Dólar Estadounidense", rate: 1 },
  { code: "EUR", symbol: "€", name: "Euro", rate: 0.92 },
  { code: "CLP", symbol: "$", name: "Peso Chileno", rate: 950 },
  { code: "COP", symbol: "$", name: "Peso Colombiano", rate: 4100 },
  { code: "MXN", symbol: "$", name: "Peso Mexicano", rate: 17.5 },
  { code: "ARS", symbol: "$", name: "Peso Argentino", rate: 850 },
]

type CurrencyContextType = {
  currency: Currency
  setCurrency: (currency: Currency) => void
  convertPrice: (priceInUSD: number) => number
  formatPrice: (priceInUSD: number) => string
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined)

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [currency, setCurrencyState] = useState<Currency>(currencies[0])

  useEffect(() => {
    const saved = localStorage.getItem("preferred-currency")
    if (saved) {
      const found = currencies.find((c) => c.code === saved)
      if (found) setCurrencyState(found)
    }
  }, [])

  const setCurrency = (newCurrency: Currency) => {
    setCurrencyState(newCurrency)
    localStorage.setItem("preferred-currency", newCurrency.code)
  }

  const convertPrice = (priceInUSD: number) => {
    return priceInUSD * currency.rate
  }

  const formatPrice = (priceInUSD: number) => {
    const converted = convertPrice(priceInUSD)
    return `${currency.symbol}${converted.toLocaleString("es", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    })}`
  }

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency, convertPrice, formatPrice }}>
      {children}
    </CurrencyContext.Provider>
  )
}

export function useCurrency() {
  const context = useContext(CurrencyContext)
  if (!context) {
    throw new Error("useCurrency must be used within CurrencyProvider")
  }
  return context
}
