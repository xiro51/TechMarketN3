"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export type Language = "es" | "en"

type Translations = {
  [key: string]: {
    es: string
    en: string
  }
}

export const translations: Translations = {
  // Header
  appName: { es: "TechMarket", en: "TechMarket" },
  inventorySystem: { es: "Sistema de Inventario", en: "Inventory System" },

  // Stats
  totalProducts: { es: "Total de Productos", en: "Total Products" },
  lowStock: { es: "Stock Bajo", en: "Low Stock" },
  totalValue: { es: "Valor Total", en: "Total Value" },
  categories: { es: "Categorías", en: "Categories" },

  // Products
  products: { es: "Productos", en: "Products" },
  manageInventory: { es: "Gestiona tu inventario de productos", en: "Manage your product inventory" },
  addProduct: { es: "Agregar Producto", en: "Add Product" },
  editProduct: { es: "Editar Producto", en: "Edit Product" },
  deleteProduct: { es: "Eliminar", en: "Delete" },
  edit: { es: "Editar", en: "Edit" },
  searchPlaceholder: { es: "Buscar por nombre, SKU o categoría...", en: "Search by name, SKU or category..." },
  noProducts: { es: "No se encontraron productos", en: "No products found" },
  lowStockBadge: { es: "Stock Bajo", en: "Low Stock" },

  // Product Dialog
  productName: { es: "Nombre del Producto", en: "Product Name" },
  category: { es: "Categoría", en: "Category" },
  price: { es: "Precio (USD)", en: "Price (USD)" },
  stock: { es: "Stock", en: "Stock" },
  minStock: { es: "Stock Mínimo", en: "Minimum Stock" },
  sku: { es: "SKU", en: "SKU" },
  cancel: { es: "Cancelar", en: "Cancel" },
  save: { es: "Guardar", en: "Save" },

  // Categories
  computers: { es: "Computadoras", en: "Computers" },
  accessories: { es: "Accesorios", en: "Accessories" },
  monitors: { es: "Monitores", en: "Monitors" },
  storage: { es: "Almacenamiento", en: "Storage" },
  networking: { es: "Redes", en: "Networking" },

  // Units
  units: { es: "unidades", en: "units" },
}

type LanguageContextType = {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("es")

  const t = (key: string): string => {
    return translations[key]?.[language] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
