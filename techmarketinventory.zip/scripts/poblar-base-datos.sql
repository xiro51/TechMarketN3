-- Datos de ejemplo para TechMarket

-- Insertar categorias
INSERT INTO categorias (nombre, descripcion) VALUES
('Computadoras', 'Laptops, desktops y componentes de computadora'),
('Accesorios', 'Teclados, ratones, auriculares y otros accesorios'),
('Monitores', 'Pantallas y monitores de computadora'),
('Almacenamiento', 'Discos duros, SSDs y dispositivos de almacenamiento'),
('Redes', 'Routers, switches y equipos de red')
ON CONFLICT (nombre) DO NOTHING;

-- Insertar productos de ejemplo
INSERT INTO productos (nombre, categoria, precio, stock, stock_minimo, sku) VALUES
('Laptop Dell XPS 15', 'Computadoras', 1299.00, 15, 5, 'DELL-XPS-15'),
('Mouse Logitech MX Master 3', 'Accesorios', 99.00, 45, 10, 'LOG-MX3'),
('Teclado Mecanico Keychron K2', 'Accesorios', 89.00, 3, 8, 'KEY-K2'),
('Monitor LG UltraWide 34', 'Monitores', 599.00, 8, 3, 'LG-UW34'),
('Webcam Logitech C920', 'Accesorios', 79.00, 22, 10, 'LOG-C920'),
('SSD Samsung 970 EVO 1TB', 'Almacenamiento', 149.00, 30, 15, 'SAM-970-1TB'),
('Router TP-Link AX3000', 'Redes', 129.00, 12, 5, 'TPL-AX3000'),
('Laptop HP Pavilion 15', 'Computadoras', 899.00, 20, 8, 'HP-PAV-15'),
('Monitor ASUS 27 4K', 'Monitores', 449.00, 10, 4, 'ASUS-27-4K'),
('Disco Duro Externo WD 2TB', 'Almacenamiento', 79.00, 25, 10, 'WD-EXT-2TB')
ON CONFLICT (sku) DO NOTHING;

-- Insertar usuario administrador de ejemplo (contrasena: admin123)
INSERT INTO usuarios (nombre_usuario, email, hash_contrasena, rol) VALUES
('admin', 'admin@techmarket.com', '$2a$10$rKZLvXZnJZ8qXqXqXqXqXeO7qXqXqXqXqXqXqXqXqXqXqXqXqXqXq', 'admin')
ON CONFLICT (nombre_usuario) DO NOTHING;

-- Insertar algunos movimientos de inventario de ejemplo
INSERT INTO movimientos_inventario (producto_id, tipo_movimiento, cantidad, razon, usuario_id) VALUES
(1, 'ENTRADA', 10, 'Compra inicial', 1),
(2, 'ENTRADA', 50, 'Reabastecimiento', 1),
(3, 'SALIDA', 5, 'Venta', 1),
(4, 'ENTRADA', 8, 'Compra inicial', 1),
(5, 'ENTRADA', 25, 'Reabastecimiento', 1);
