-- Seed data for TechMarket Inventory System

-- Insert categories
INSERT INTO categories (name, description) VALUES
    ('Computadoras', 'Laptops, desktops y componentes'),
    ('Accesorios', 'Periféricos y accesorios de computadora'),
    ('Monitores', 'Pantallas y monitores'),
    ('Almacenamiento', 'Discos duros y SSDs'),
    ('Redes', 'Routers, switches y equipos de red')
ON CONFLICT (name) DO NOTHING;

-- Insert sample products
INSERT INTO products (name, category, price, stock, min_stock, sku) VALUES
    ('Laptop Dell XPS 15', 'Computadoras', 1299.00, 15, 5, 'DELL-XPS-15'),
    ('Mouse Logitech MX Master 3', 'Accesorios', 99.00, 45, 10, 'LOG-MX3'),
    ('Teclado Mecánico Keychron K2', 'Accesorios', 89.00, 3, 8, 'KEY-K2'),
    ('Monitor LG UltraWide 34', 'Monitores', 599.00, 8, 3, 'LG-UW34'),
    ('Webcam Logitech C920', 'Accesorios', 79.00, 22, 10, 'LOG-C920'),
    ('SSD Samsung 970 EVO 1TB', 'Almacenamiento', 149.00, 30, 15, 'SAM-970-1TB'),
    ('Router TP-Link AX3000', 'Redes', 129.00, 12, 5, 'TPL-AX3000'),
    ('Laptop MacBook Pro 14', 'Computadoras', 1999.00, 6, 3, 'APPLE-MBP14'),
    ('Monitor Dell UltraSharp 27', 'Monitores', 449.00, 10, 4, 'DELL-US27'),
    ('Disco Duro WD 4TB', 'Almacenamiento', 89.00, 25, 10, 'WD-4TB')
ON CONFLICT (sku) DO NOTHING;

-- Insert sample users (passwords should be hashed in production)
INSERT INTO users (username, email, password_hash, role) VALUES
    ('admin', 'admin@techmarket.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
    ('usuario', 'user@techmarket.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user')
ON CONFLICT (username) DO NOTHING;

-- Insert sample inventory movements
INSERT INTO inventory_movements (product_id, movement_type, quantity, reason) VALUES
    (1, 'IN', 15, 'Stock inicial'),
    (2, 'IN', 45, 'Stock inicial'),
    (3, 'IN', 3, 'Stock inicial'),
    (4, 'IN', 8, 'Stock inicial'),
    (5, 'IN', 22, 'Stock inicial');
