"use client"

import { useState } from "react"
import { Package, Plus, Search, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CurrencySwitcher } from "@/components/currency-switcher"
import { LanguageSwitcher } from "@/components/language-switcher"
import { useCurrency } from "@/components/currency-provider"
import { useLanguage } from "@/components/language-provider"
import { ProductDialog } from "@/components/product-dialog"
import { StatsCards } from "@/components/stats-cards"

export type Product = {
  id: string
  name: string
  category: string
  price: number // Price in USD
  stock: number
  minStock: number
  sku: string
}

const initialProducts: Product[] = [
  {
    id: "1",
    name: "Laptop Dell XPS 15",
    category: "Computadoras",
    price: 1299,
    stock: 15,
    minStock: 5,
    sku: "DELL-XPS-15",
  },
  {
    id: "2",
    name: "Mouse Logitech MX Master 3",
    category: "Accesorios",
    price: 99,
    stock: 45,
    minStock: 10,
    sku: "LOG-MX3",
  },
  {
    id: "3",
    name: "Teclado Mecánico Keychron K2",
    category: "Accesorios",
    price: 89,
    stock: 3,
    minStock: 8,
    sku: "KEY-K2",
  },
  {
    id: "4",
    name: "Monitor LG UltraWide 34",
    category: "Monitores",
    price: 599,
    stock: 8,
    minStock: 3,
    sku: "LG-UW34",
  },
  {
    id: "5",
    name: "Webcam Logitech C920",
    category: "Accesorios",
    price: 79,
    stock: 22,
    minStock: 10,
    sku: "LOG-C920",
  },
]

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>(initialProducts)
  const [searchQuery, setSearchQuery] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | undefined>()
  const { formatPrice } = useCurrency()
  const { t } = useLanguage()

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAddProduct = (product: Omit<Product, "id">) => {
    const newProduct = {
      ...product,
      id: Date.now().toString(),
    }
    setProducts([...products, newProduct])
  }

  const handleEditProduct = (product: Product) => {
    setProducts(products.map((p) => (p.id === product.id ? product : p)))
  }

  const handleDeleteProduct = (id: string) => {
    setProducts(products.filter((p) => p.id !== id))
  }

  const openAddDialog = () => {
    setEditingProduct(undefined)
    setDialogOpen(true)
  }

  const openEditDialog = (product: Product) => {
    setEditingProduct(product)
    setDialogOpen(true)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Package className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">{t("appName")}</h1>
                <p className="text-sm text-muted-foreground">{t("inventorySystem")}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSwitcher />
              <CurrencySwitcher />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Stats */}
        <StatsCards products={products} />

        {/* Products Section */}
        <Card className="mt-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl">{t("products")}</CardTitle>
                <CardDescription>{t("manageInventory")}</CardDescription>
              </div>
              <Button onClick={openAddDialog} className="gap-2">
                <Plus className="h-4 w-4" />
                {t("addProduct")}
              </Button>
            </div>
            <div className="mt-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder={t("searchPlaceholder")}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredProducts.length === 0 ? (
                <div className="text-center py-12">
                  <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">{t("noProducts")}</p>
                </div>
              ) : (
                filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-foreground">{product.name}</h3>
                        <Badge variant="secondary">{product.category}</Badge>
                        {product.stock <= product.minStock && (
                          <Badge variant="destructive" className="gap-1">
                            <AlertCircle className="h-3 w-3" />
                            {t("lowStockBadge")}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>
                          {t("sku")}: {product.sku}
                        </span>
                        <span>
                          {t("stock")}: {product.stock} {t("units")}
                        </span>
                        <span className="font-semibold text-foreground">{formatPrice(product.price)}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => openEditDialog(product)}>
                        {t("edit")}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteProduct(product.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        {t("deleteProduct")}
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </main>

      <ProductDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        product={editingProduct}
        onSave={(product) => {
          if (editingProduct) {
            handleEditProduct(product as Product)
          } else {
            handleAddProduct(product)
          }
          setDialogOpen(false)
        }}
      />
    </div>
  )
}
