import type { Product } from "./db"

export interface ReportFilters {
  category?: string
  minQuantity?: number
  maxQuantity?: number
  minPrice?: number
  maxPrice?: number
  dateFrom?: string
  dateTo?: string
}

export const filterProductsForReport = (products: Product[], filters: ReportFilters): Product[] => {
  let filtered = [...products]

  if (filters.category && filters.category !== "all") {
    filtered = filtered.filter((p) => p.category === filters.category)
  }

  if (filters.minQuantity !== undefined) {
    filtered = filtered.filter((p) => p.quantity >= filters.minQuantity!)
  }

  if (filters.maxQuantity !== undefined) {
    filtered = filtered.filter((p) => p.quantity <= filters.maxQuantity!)
  }

  if (filters.minPrice !== undefined) {
    filtered = filtered.filter((p) => p.price >= filters.minPrice!)
  }

  if (filters.maxPrice !== undefined) {
    filtered = filtered.filter((p) => p.price <= filters.maxPrice!)
  }

  if (filters.dateFrom) {
    filtered = filtered.filter((p) => new Date(p.createdAt) >= new Date(filters.dateFrom!))
  }

  if (filters.dateTo) {
    filtered = filtered.filter((p) => new Date(p.createdAt) <= new Date(filters.dateTo!))
  }

  return filtered
}

export const generateCSV = (products: Product[]): string => {
  const headers = ["Product Name", "Category", "Quantity", "Price", "Total Value", "Created At", "Updated At"]
  const rows = products.map((p) => [
    p.name,
    p.category,
    p.quantity.toString(),
    p.price.toFixed(2),
    (p.quantity * p.price).toFixed(2),
    new Date(p.createdAt).toLocaleDateString(),
    new Date(p.updatedAt).toLocaleDateString(),
  ])

  const csvContent = [headers, ...rows].map((row) => row.map((cell) => `"${cell}"`).join(",")).join("\n")

  return csvContent
}

export const downloadCSV = (products: Product[], filename = "inventory-report.csv") => {
  const csv = generateCSV(products)
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
  const link = document.createElement("a")
  const url = URL.createObjectURL(blob)

  link.setAttribute("href", url)
  link.setAttribute("download", filename)
  link.style.visibility = "hidden"
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

export const generatePDFContent = (products: Product[]): string => {
  const totalValue = products.reduce((sum, p) => sum + p.quantity * p.price, 0)
  const totalQuantity = products.reduce((sum, p) => sum + p.quantity, 0)

  let html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Inventory Report</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          padding: 40px;
          color: #333;
        }
        .header {
          text-align: center;
          margin-bottom: 30px;
          border-bottom: 2px solid #333;
          padding-bottom: 20px;
        }
        .header h1 {
          margin: 0;
          font-size: 28px;
        }
        .header p {
          margin: 5px 0;
          color: #666;
        }
        .summary {
          display: flex;
          justify-content: space-around;
          margin: 30px 0;
          padding: 20px;
          background: #f5f5f5;
          border-radius: 8px;
        }
        .summary-item {
          text-align: center;
        }
        .summary-item .label {
          font-size: 12px;
          color: #666;
          text-transform: uppercase;
        }
        .summary-item .value {
          font-size: 24px;
          font-weight: bold;
          margin-top: 5px;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        th, td {
          padding: 12px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        th {
          background-color: #333;
          color: white;
          font-weight: bold;
        }
        tr:hover {
          background-color: #f5f5f5;
        }
        .footer {
          margin-top: 40px;
          text-align: center;
          color: #666;
          font-size: 12px;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>TechMarket Inventory Report</h1>
        <p>Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}</p>
      </div>
      
      <div class="summary">
        <div class="summary-item">
          <div class="label">Total Products</div>
          <div class="value">${products.length}</div>
        </div>
        <div class="summary-item">
          <div class="label">Total Quantity</div>
          <div class="value">${totalQuantity}</div>
        </div>
        <div class="summary-item">
          <div class="label">Total Value</div>
          <div class="value">$${totalValue.toFixed(2)}</div>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Category</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total Value</th>
          </tr>
        </thead>
        <tbody>
  `

  products.forEach((product) => {
    html += `
          <tr>
            <td>${product.name}</td>
            <td>${product.category}</td>
            <td>${product.quantity}</td>
            <td>$${product.price.toFixed(2)}</td>
            <td>$${(product.quantity * product.price).toFixed(2)}</td>
          </tr>
    `
  })

  html += `
        </tbody>
      </table>
      
      <div class="footer">
        <p>TechMarket Inventory Management System</p>
      </div>
    </body>
    </html>
  `

  return html
}

export const downloadPDF = (products: Product[], filename = "inventory-report.pdf") => {
  const htmlContent = generatePDFContent(products)
  const blob = new Blob([htmlContent], { type: "text/html" })
  const url = URL.createObjectURL(blob)

  // Open in new window for printing to PDF
  const printWindow = window.open(url, "_blank")
  if (printWindow) {
    printWindow.onload = () => {
      printWindow.print()
    }
  }
}
