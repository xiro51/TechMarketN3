import { createClient } from "@supabase/supabase-js"

// Estas variables de entorno deben ser configuradas en tu proyecto
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

// Cliente de Supabase para uso en el cliente
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Tipos de la base de datos
export type Producto = {
  id: number
  nombre: string
  categoria: string
  precio: number
  stock: number
  stock_minimo: number
  sku: string
  fecha_creacion: string
  fecha_actualizacion: string
}

export type Categoria = {
  id: number
  nombre: string
  descripcion: string | null
  fecha_creacion: string
}

export type MovimientoInventario = {
  id: number
  producto_id: number
  tipo_movimiento: "ENTRADA" | "SALIDA"
  cantidad: number
  razon: string | null
  usuario_id: number | null
  fecha_creacion: string
}

export type Usuario = {
  id: number
  nombre_usuario: string
  email: string
  rol: "admin" | "usuario"
  fecha_creacion: string
  fecha_actualizacion: string
}
