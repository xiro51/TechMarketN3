let allProducts = []
const currentUserId = null

// Load products on page load
document.addEventListener("DOMContentLoaded", () => {
  loadProducts()
})

async function loadProducts() {
  try {
    const response = await fetch("api/products.php")
    allProducts = await response.json()
    updateStats()
    filterProducts()
  } catch (error) {
    console.error("Error loading products:", error)
  }
}

function updateStats() {
  const totalProducts = allProducts.length
  const totalValue = allProducts.reduce((sum, p) => sum + p.quantity * p.price, 0)
  const lowStock = allProducts.filter((p) => p.quantity < 10 && p.quantity > 0).length
  const outOfStock = allProducts.filter((p) => p.quantity === 0).length

  document.getElementById("totalProducts").textContent = totalProducts
  document.getElementById("totalValue").textContent = `$${totalValue.toFixed(2)}`
  document.getElementById("lowStock").textContent = lowStock
  document.getElementById("outOfStock").textContent = outOfStock
}

function filterProducts() {
  const searchQuery = document.getElementById("searchInput").value.toLowerCase()
  const categoryFilter = document.getElementById("categoryFilter").value

  let filtered = allProducts

  if (searchQuery) {
    filtered = filtered.filter((p) => p.name.toLowerCase().includes(searchQuery))
  }

  if (categoryFilter !== "all") {
    filtered = filtered.filter((p) => p.category === categoryFilter)
  }

  renderProducts(filtered)
}

function renderProducts(products) {
  const tbody = document.getElementById("productsTableBody")

  if (products.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center">No se encontraron productos</td></tr>'
    return
  }

  tbody.innerHTML = products
    .map((product) => {
      const stockBadge =
        product.quantity === 0 ? "badge-danger" : product.quantity < 10 ? "badge-warning" : "badge-success"
      const stockText = product.quantity === 0 ? "Sin Stock" : product.quantity < 10 ? "Stock Bajo" : "En Stock"

      return `
            <tr>
                <td>
                    <div style="font-weight: 600;">${product.name}</div>
                    <div style="font-size: 0.875rem; color: var(--text-muted);">ID: ${product.id}</div>
                </td>
                <td><span class="badge badge-primary">${product.category}</span></td>
                <td>
                    <span class="badge ${stockBadge}">${product.quantity} unidades</span>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">${stockText}</div>
                </td>
                <td style="font-weight: 600;">$${Number.parseFloat(product.price).toFixed(2)}</td>
                <td style="font-weight: 600; color: var(--success);">$${(product.quantity * product.price).toFixed(2)}</td>
                <td>
                    <div class="action-buttons">
                        <button onclick="editProduct('${product.id}')" class="btn-sm btn-edit">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Editar
                        </button>
                        <button onclick="deleteProduct('${product.id}')" class="btn-sm btn-delete">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                            Eliminar
                        </button>
                    </div>
                </td>
            </tr>
        `
    })
    .join("")
}

function openAddProductModal() {
  document.getElementById("modalTitle").textContent = "Agregar Producto"
  document.getElementById("productForm").reset()
  document.getElementById("productId").value = ""
  document.getElementById("productModal").classList.add("active")
}

function editProduct(id) {
  const product = allProducts.find((p) => p.id === id)
  if (!product) return

  document.getElementById("modalTitle").textContent = "Editar Producto"
  document.getElementById("productId").value = product.id
  document.getElementById("productName").value = product.name
  document.getElementById("productCategory").value = product.category
  document.getElementById("productQuantity").value = product.quantity
  document.getElementById("productPrice").value = product.price
  document.getElementById("productModal").classList.add("active")
}

async function deleteProduct(id) {
  if (!confirm("¿Estás seguro de que quieres eliminar este producto?")) return

  try {
    const response = await fetch("api/products.php", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ id }),
    })

    const data = await response.json()
    if (data.success) {
      await loadProducts()
    }
  } catch (error) {
    console.error("Error deleting product:", error)
    alert("Error al eliminar el producto")
  }
}

function closeProductModal() {
  document.getElementById("productModal").classList.remove("active")
}

async function handleProductSubmit(e) {
  e.preventDefault()

  const id = document.getElementById("productId").value
  const name = document.getElementById("productName").value
  const category = document.getElementById("productCategory").value
  const quantity = Number.parseInt(document.getElementById("productQuantity").value)
  const price = Number.parseFloat(document.getElementById("productPrice").value)

  const data = { name, category, quantity, price }

  try {
    if (id) {
      // Update
      data.id = id
      await fetch("api/products.php", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
    } else {
      // Create
      await fetch("api/products.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
    }

    closeProductModal()
    await loadProducts()
  } catch (error) {
    console.error("Error saving product:", error)
    alert("Error al guardar el producto")
  }
}

async function logout() {
  try {
    await fetch("api/logout.php")
    window.location.href = "index.php"
  } catch (error) {
    console.error("Error logging out:", error)
  }
}

// Close modal when clicking outside
document.getElementById("productModal").addEventListener("click", (e) => {
  if (e.target.id === "productModal") {
    closeProductModal()
  }
})
