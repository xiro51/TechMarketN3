document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault()

  const username = document.getElementById("username").value
  const password = document.getElementById("password").value
  const errorMessage = document.getElementById("errorMessage")
  const loginBtn = document.getElementById("loginBtn")
  const loginText = document.getElementById("loginText")
  const loginLoader = document.getElementById("loginLoader")

  // Show loading state
  loginBtn.disabled = true
  loginText.style.display = "none"
  loginLoader.style.display = "block"
  errorMessage.style.display = "none"

  try {
    const response = await fetch("api/login.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password }),
    })

    const data = await response.json()

    if (data.success) {
      window.location.href = "dashboard.php"
    } else {
      errorMessage.textContent = data.error || "Usuario o contraseña inválidos"
      errorMessage.style.display = "block"
    }
  } catch (error) {
    errorMessage.textContent = "Ocurrió un error. Por favor intenta de nuevo."
    errorMessage.style.display = "block"
  } finally {
    loginBtn.disabled = false
    loginText.style.display = "block"
    loginLoader.style.display = "none"
  }
})
