let allUsers = []
let allProducts = []
const currentUserId = null

document.addEventListener("DOMContentLoaded", () => {
  loadUsers()
  loadProducts()
  setupReportFilters()
})

async function loadUsers() {
  try {
    const response = await fetch("api/users.php")
    allUsers = await response.json()
    renderUsers()
  } catch (error) {
    console.error("Error loading users:", error)
  }
}

async function loadProducts() {
  try {
    const response = await fetch("api/products.php")
    allProducts = await response.json()
    updateReportPreview()
  } catch (error) {
    console.error("Error loading products:", error)
  }
}

function renderUsers() {
  const tbody = document.getElementById("usersTableBody")

  if (allUsers.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" class="text-center">No hay usuarios</td></tr>'
    return
  }

  tbody.innerHTML = allUsers
    .map((user) => {
      const isCurrentUser = user.id === currentUserId
      const roleBadge = user.role === "Admin" ? "badge-primary" : "badge-secondary"
      const date = new Date(user.createdAt).toLocaleDateString("es-ES")

      return `
            <tr>
                <td>
                    <div style="font-weight: 600;">${user.username}</div>
                    ${isCurrentUser ? '<div style="font-size: 0.75rem; color: var(--primary);">(Tú)</div>' : ""}
                </td>
                <td><span class="badge ${roleBadge}">${user.role}</span></td>
                <td>${date}</td>
                <td>
                    <div class="action-buttons">
                        <button onclick="editUser('${user.id}')" class="btn-sm btn-edit">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Editar
                        </button>
                        ${
                          !isCurrentUser
                            ? `
                            <button onclick="deleteUser('${user.id}')" class="btn-sm btn-delete">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="3 6 5 6 21 6"></polyline>
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                </svg>
                                Eliminar
                            </button>
                        `
                            : ""
                        }
                    </div>
                </td>
            </tr>
        `
    })
    .join("")
}

function switchTab(tab) {
  // Update tab buttons
  document.querySelectorAll(".tab-button").forEach((btn) => {
    btn.classList.remove("active")
  })
  event.target.closest(".tab-button").classList.add("active")

  // Update tab content
  document.querySelectorAll(".tab-content").forEach((content) => {
    content.classList.remove("active")
  })
  document.getElementById(tab + "Tab").classList.add("active")
}

function openAddUserModal() {
  document.getElementById("userModalTitle").textContent = "Agregar Usuario"
  document.getElementById("userForm").reset()
  document.getElementById("userId").value = ""
  document.getElementById("userPassword").required = true
  document.getElementById("passwordHint").style.display = "none"
  document.getElementById("userModal").classList.add("active")
}

function editUser(id) {
  const user = allUsers.find((u) => u.id === id)
  if (!user) return

  document.getElementById("userModalTitle").textContent = "Editar Usuario"
  document.getElementById("userId").value = user.id
  document.getElementById("userName").value = user.username
  document.getElementById("userName").disabled = true
  document.getElementById("userPassword").value = ""
  document.getElementById("userPassword").required = false
  document.getElementById("passwordHint").style.display = "block"
  document.getElementById("userRole").value = user.role
  document.getElementById("userModal").classList.add("active")
}

async function deleteUser(id) {
  if (!confirm("¿Estás seguro de que quieres eliminar este usuario?")) return

  try {
    const response = await fetch("api/users.php", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ id }),
    })

    const data = await response.json()
    if (data.success) {
      await loadUsers()
    }
  } catch (error) {
    console.error("Error deleting user:", error)
    alert("Error al eliminar el usuario")
  }
}

function closeUserModal() {
  document.getElementById("userModal").classList.remove("active")
  document.getElementById("userName").disabled = false
}

async function handleUserSubmit(e) {
  e.preventDefault()

  const id = document.getElementById("userId").value
  const username = document.getElementById("userName").value
  const password = document.getElementById("userPassword").value
  const role = document.getElementById("userRole").value

  const data = { username, password, role }

  try {
    if (id) {
      // Update
      data.id = id
      if (!password) {
        delete data.password
      }
      await fetch("api/users.php", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
    } else {
      // Create
      const response = await fetch("api/users.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      const result = await response.json()
      if (result.error) {
        alert(result.error)
        return
      }
    }

    closeUserModal()
    await loadUsers()
  } catch (error) {
    console.error("Error saving user:", error)
    alert("Error al guardar el usuario")
  }
}

// Report functionality
function setupReportFilters() {
  const filters = [
    "reportCategory",
    "reportDateFrom",
    "reportDateTo",
    "reportMinQty",
    "reportMaxQty",
    "reportMinPrice",
    "reportMaxPrice",
  ]
  filters.forEach((id) => {
    document.getElementById(id).addEventListener("change", updateReportPreview)
    document.getElementById(id).addEventListener("input", updateReportPreview)
  })
}

function getFilteredProducts() {
  const category = document.getElementById("reportCategory").value
  const dateFrom = document.getElementById("reportDateFrom").value
  const dateTo = document.getElementById("reportDateTo").value
  const minQty = document.getElementById("reportMinQty").value
  const maxQty = document.getElementById("reportMaxQty").value
  const minPrice = document.getElementById("reportMinPrice").value
  const maxPrice = document.getElementById("reportMaxPrice").value

  let filtered = allProducts

  if (category !== "all") {
    filtered = filtered.filter((p) => p.category === category)
  }

  if (dateFrom) {
    filtered = filtered.filter((p) => new Date(p.createdAt) >= new Date(dateFrom))
  }

  if (dateTo) {
    filtered = filtered.filter((p) => new Date(p.createdAt) <= new Date(dateTo))
  }

  if (minQty) {
    filtered = filtered.filter((p) => p.quantity >= Number.parseInt(minQty))
  }

  if (maxQty) {
    filtered = filtered.filter((p) => p.quantity <= Number.parseInt(maxQty))
  }

  if (minPrice) {
    filtered = filtered.filter((p) => p.price >= Number.parseFloat(minPrice))
  }

  if (maxPrice) {
    filtered = filtered.filter((p) => p.price <= Number.parseFloat(maxPrice))
  }

  return filtered
}

function updateReportPreview() {
  const filtered = getFilteredProducts()
  const tbody = document.getElementById("reportPreviewBody")
  document.getElementById("reportCount").textContent = filtered.length

  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center">No hay productos que coincidan con los filtros</td></tr>'
    return
  }

  tbody.innerHTML = filtered
    .slice(0, 10)
    .map(
      (product) => `
        <tr>
            <td>${product.name}</td>
            <td><span class="badge badge-primary">${product.category}</span></td>
            <td>${product.quantity}</td>
            <td>$${Number.parseFloat(product.price).toFixed(2)}</td>
            <td style="font-weight: 600;">$${(product.quantity * product.price).toFixed(2)}</td>
        </tr>
    `,
    )
    .join("")

  if (filtered.length > 10) {
    tbody.innerHTML += `<tr><td colspan="5" class="text-center" style="color: var(--text-muted);">... y ${filtered.length - 10} productos más</td></tr>`
  }
}

function generateReport(format) {
  const filtered = getFilteredProducts()

  if (filtered.length === 0) {
    alert("No hay productos para exportar")
    return
  }

  if (format === "csv") {
    generateCSV(filtered)
  } else if (format === "pdf") {
    generatePDF(filtered)
  }
}

function generateCSV(products) {
  const headers = ["Nombre", "Categoría", "Cantidad", "Precio", "Valor Total"]
  const rows = products.map((p) => [
    p.name,
    p.category,
    p.quantity,
    p.price.toFixed(2),
    (p.quantity * p.price).toFixed(2),
  ])

  let csv = headers.join(",") + "\n"
  rows.forEach((row) => {
    csv += row.map((cell) => `"${cell}"`).join(",") + "\n"
  })

  const blob = new Blob([csv], { type: "text/csv" })
  const url = window.URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = `reporte-inventario-${new Date().toISOString().split("T")[0]}.csv`
  a.click()
  window.URL.revokeObjectURL(url)
}

function generatePDF(products) {
  const { jsPDF } = window.jspdf
  const doc = new jsPDF()

  // Title
  doc.setFontSize(18)
  doc.text("Reporte de Inventario", 14, 20)

  // Date
  doc.setFontSize(10)
  doc.text(`Fecha: ${new Date().toLocaleDateString("es-ES")}`, 14, 28)
  doc.text(`Total de productos: ${products.length}`, 14, 34)

  // Table headers
  let y = 45
  doc.setFontSize(10)
  doc.setFont(undefined, "bold")
  doc.text("Nombre", 14, y)
  doc.text("Categoría", 80, y)
  doc.text("Cantidad", 120, y)
  doc.text("Precio", 150, y)
  doc.text("Total", 175, y)

  // Table rows
  doc.setFont(undefined, "normal")
  y += 7

  products.forEach((product, index) => {
    if (y > 280) {
      doc.addPage()
      y = 20
    }

    doc.text(product.name.substring(0, 30), 14, y)
    doc.text(product.category, 80, y)
    doc.text(product.quantity.toString(), 120, y)
    doc.text(`$${product.price.toFixed(2)}`, 150, y)
    doc.text(`$${(product.quantity * product.price).toFixed(2)}`, 175, y)

    y += 7
  })

  // Total
  const totalValue = products.reduce((sum, p) => sum + p.quantity * p.price, 0)
  y += 5
  doc.setFont(undefined, "bold")
  doc.text(`Valor Total del Inventario: $${totalValue.toFixed(2)}`, 14, y)

  doc.save(`reporte-inventario-${new Date().toISOString().split("T")[0]}.pdf`)
}

async function logout() {
  try {
    await fetch("api/logout.php")
    window.location.href = "index.php"
  } catch (error) {
    console.error("Error logging out:", error)
  }
}

// Close modal when clicking outside
document.getElementById("userModal").addEventListener("click", (e) => {
  if (e.target.id === "userModal") {
    closeUserModal()
  }
})
