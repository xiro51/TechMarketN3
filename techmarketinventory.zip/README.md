# TechMarket - Sistema de Inventario

Sistema de gestión de inventario moderno con tema oscuro, cambio de moneda y soporte multiidioma.

## Características

- 🌙 Tema oscuro por defecto
- 💱 Cambio de moneda (USD, EUR, CLP, COP, MXN, ARS)
- 🌍 Soporte multiidioma (Español e Inglés)
- 📦 Gestión completa de productos
- 📊 Estadísticas en tiempo real
- 🔍 Búsqueda de productos
- ⚠️ Alertas de stock bajo

## Base de Datos

### Configuración

Para conectar la base de datos, necesitas agregar las siguientes variables de entorno:

\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=tu_url_de_supabase
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_clave_anonima_de_supabase
\`\`\`

### Scripts SQL

Los scripts para crear y poblar la base de datos están en la carpeta `scripts/`:

1. `crear-base-datos.sql` - Crea las tablas necesarias (productos, categorias, movimientos_inventario, usuarios)
2. `poblar-base-datos.sql` - Inserta datos de ejemplo

### Estructura de la Base de Datos

- **productos**: Almacena información de productos
- **categorias**: Categorías de productos
- **movimientos_inventario**: Historial de entradas y salidas de stock
- **usuarios**: Usuarios del sistema con roles

## Instalación

\`\`\`bash
npm install
npm run dev
\`\`\`

## Uso

1. Configura las variables de entorno para la base de datos
2. Ejecuta los scripts SQL en tu base de datos Supabase
3. Inicia la aplicación
4. Usa los botones de cambio de idioma y moneda en el header
