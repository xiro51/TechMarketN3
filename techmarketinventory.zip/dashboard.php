<?php
require_once __DIR__ . '/config/auth.php';

$auth = new Auth();
$auth->requireLogin();
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechMarket - Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="dashboard">
        <!-- Header -->
        <header class="dashboard-header">
            <div class="header-content">
                <div class="header-left">
                    <div class="logo-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                        </svg>
                    </div>
                    <h1>TechMarket</h1>
                </div>
                <div class="header-right">
                    <span class="user-info">
                        <span class="user-name"><?php echo htmlspecialchars($user['username']); ?></span>
                        <span class="user-role"><?php echo htmlspecialchars($user['role']); ?></span>
                    </span>
                    <button onclick="logout()" class="btn-secondary">Cerrar Sesión</button>
                </div>
            </div>
        </header>
        
        <main class="dashboard-main">
            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-label">Total Productos</span>
                        <div class="stat-icon stat-icon-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="stat-value" id="totalProducts">0</div>
                    <div class="stat-description">Artículos en inventario</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-label">Valor Total</span>
                        <div class="stat-icon stat-icon-success">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="12" y1="1" x2="12" y2="23"></line>
                                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="stat-value" id="totalValue">$0.00</div>
                    <div class="stat-description">Valor del inventario</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-label">Stock Bajo</span>
                        <div class="stat-icon stat-icon-warning">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                                <line x1="12" y1="9" x2="12" y2="13"></line>
                                <line x1="12" y1="17" x2="12.01" y2="17"></line>
                            </svg>
                        </div>
                    </div>
                    <div class="stat-value" id="lowStock">0</div>
                    <div class="stat-description">Menos de 10 unidades</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-label">Sin Stock</span>
                        <div class="stat-icon stat-icon-danger">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                                <line x1="12" y1="9" x2="12" y2="13"></line>
                                <line x1="12" y1="17" x2="12.01" y2="17"></line>
                            </svg>
                        </div>
                    </div>
                    <div class="stat-value stat-value-danger" id="outOfStock">0</div>
                    <div class="stat-description">Necesita reabastecimiento</div>
                </div>
            </div>
            
            <?php if ($user['role'] === 'Admin'): ?>
            <!-- Admin Panel Link -->
            <div class="admin-banner">
                <div class="admin-banner-content">
                    <div class="admin-banner-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                        </svg>
                    </div>
                    <div>
                        <p class="admin-banner-title">Panel de Administración</p>
                        <p class="admin-banner-description">Gestionar usuarios y generar reportes</p>
                    </div>
                </div>
                <a href="admin.php" class="btn-primary">Ir al Panel Admin</a>
            </div>
            <?php endif; ?>
            
            <!-- Products Section -->
            <div class="card">
                <div class="card-header">
                    <div>
                        <h2 class="card-title">Productos</h2>
                        <p class="card-description">Gestiona tu inventario</p>
                    </div>
                    <button onclick="openAddProductModal()" class="btn-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="12" y1="5" x2="12" y2="19"></line>
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                        </svg>
                        Agregar Producto
                    </button>
                </div>
                
                <div class="card-content">
                    <!-- Filters -->
                    <div class="filters">
                        <div class="search-box">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="11" cy="11" r="8"></circle>
                                <path d="m21 21-4.35-4.35"></path>
                            </svg>
                            <input type="text" id="searchInput" placeholder="Buscar productos..." oninput="filterProducts()">
                        </div>
                        <select id="categoryFilter" onchange="filterProducts()" class="select-input">
                            <option value="all">Todas las Categorías</option>
                            <option value="Electronics">Electronics</option>
                            <option value="Computers">Computers</option>
                            <option value="Accessories">Accessories</option>
                            <option value="Peripherals">Peripherals</option>
                            <option value="Software">Software</option>
                            <option value="Networking">Networking</option>
                            <option value="Storage">Storage</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    
                    <!-- Products Table -->
                    <div class="table-container">
                        <table class="products-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Categoría</th>
                                    <th>Cantidad</th>
                                    <th>Precio</th>
                                    <th>Valor Total</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="productsTableBody">
                                <tr>
                                    <td colspan="6" class="text-center">Cargando productos...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Add/Edit Product Modal -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Agregar Producto</h3>
                <button onclick="closeProductModal()" class="modal-close">&times;</button>
            </div>
            <form id="productForm" onsubmit="handleProductSubmit(event)">
                <input type="hidden" id="productId">
                <div class="form-group">
                    <label for="productName">Nombre del Producto</label>
                    <input type="text" id="productName" required>
                </div>
                <div class="form-group">
                    <label for="productCategory">Categoría</label>
                    <select id="productCategory" required class="select-input">
                        <option value="">Seleccionar categoría</option>
                        <option value="Electronics">Electronics</option>
                        <option value="Computers">Computers</option>
                        <option value="Accessories">Accessories</option>
                        <option value="Peripherals">Peripherals</option>
                        <option value="Software">Software</option>
                        <option value="Networking">Networking</option>
                        <option value="Storage">Storage</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="productQuantity">Cantidad</label>
                    <input type="number" id="productQuantity" min="0" required>
                </div>
                <div class="form-group">
                    <label for="productPrice">Precio</label>
                    <input type="number" id="productPrice" min="0" step="0.01" required>
                </div>
                <div class="modal-footer">
                    <button type="button" onclick="closeProductModal()" class="btn-secondary">Cancelar</button>
                    <button type="submit" class="btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="js/dashboard.js"></script>
</body>
</html>
