<?php
require_once __DIR__ . '/config/auth.php';

$auth = new Auth();
$auth->requireAdmin();
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechMarket - Panel Admin</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="dashboard">
        <!-- Header -->
        <header class="dashboard-header">
            <div class="header-content">
                <div class="header-left">
                    <div class="logo-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                        </svg>
                    </div>
                    <h1>TechMarket</h1>
                </div>
                <div class="header-right">
                    <span class="user-info">
                        <span class="user-name"><?php echo htmlspecialchars($user['username']); ?></span>
                        <span class="user-role"><?php echo htmlspecialchars($user['role']); ?></span>
                    </span>
                    <button onclick="logout()" class="btn-secondary">Cerrar Sesión</button>
                </div>
            </div>
        </header>
        
        <main class="dashboard-main">
            <div class="page-header">
                <a href="dashboard.php" class="btn-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                </a>
                <div>
                    <h2 class="page-title">Panel de Administración</h2>
                    <p class="page-description">Gestionar usuarios y generar reportes</p>
                </div>
            </div>
            
            <!-- Tabs -->
            <div class="tabs">
                <button class="tab-button active" onclick="switchTab('users')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                    Gestión de Usuarios
                </button>
                <button class="tab-button" onclick="switchTab('reports')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                    Reportes
                </button>
            </div>
            
            <!-- Users Tab -->
            <div id="usersTab" class="tab-content active">
                <div class="card">
                    <div class="card-header">
                        <div>
                            <h2 class="card-title">Usuarios</h2>
                            <p class="card-description">Gestionar cuentas de usuario y roles</p>
                        </div>
                        <button onclick="openAddUserModal()" class="btn-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="12" y1="5" x2="12" y2="19"></line>
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                            </svg>
                            Agregar Usuario
                        </button>
                    </div>
                    <div class="card-content">
                        <div class="table-container">
                            <table class="products-table">
                                <thead>
                                    <tr>
                                        <th>Usuario</th>
                                        <th>Rol</th>
                                        <th>Fecha de Creación</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="usersTableBody">
                                    <tr>
                                        <td colspan="4" class="text-center">Cargando usuarios...</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Reports Tab -->
            <div id="reportsTab" class="tab-content">
                <div class="card">
                    <div class="card-header">
                        <div>
                            <h2 class="card-title">Generar Reporte</h2>
                            <p class="card-description">Exportar datos de inventario con filtros personalizados</p>
                        </div>
                    </div>
                    <div class="card-content">
                        <div class="report-filters">
                            <div class="form-group">
                                <label>Categoría</label>
                                <select id="reportCategory" class="select-input">
                                    <option value="all">Todas las Categorías</option>
                                    <option value="Electronics">Electronics</option>
                                    <option value="Computers">Computers</option>
                                    <option value="Accessories">Accessories</option>
                                    <option value="Peripherals">Peripherals</option>
                                    <option value="Software">Software</option>
                                    <option value="Networking">Networking</option>
                                    <option value="Storage">Storage</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Fecha Desde</label>
                                    <input type="date" id="reportDateFrom" class="input">
                                </div>
                                <div class="form-group">
                                    <label>Fecha Hasta</label>
                                    <input type="date" id="reportDateTo" class="input">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Cantidad Mínima</label>
                                    <input type="number" id="reportMinQty" min="0" class="input" placeholder="0">
                                </div>
                                <div class="form-group">
                                    <label>Cantidad Máxima</label>
                                    <input type="number" id="reportMaxQty" min="0" class="input" placeholder="Sin límite">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Precio Mínimo</label>
                                    <input type="number" id="reportMinPrice" min="0" step="0.01" class="input" placeholder="$0.00">
                                </div>
                                <div class="form-group">
                                    <label>Precio Máximo</label>
                                    <input type="number" id="reportMaxPrice" min="0" step="0.01" class="input" placeholder="Sin límite">
                                </div>
                            </div>
                            
                            <div class="report-actions">
                                <button onclick="generateReport('csv')" class="btn-primary">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                        <polyline points="7 10 12 15 17 10"></polyline>
                                        <line x1="12" y1="15" x2="12" y2="3"></line>
                                    </svg>
                                    Exportar CSV
                                </button>
                                <button onclick="generateReport('pdf')" class="btn-secondary">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                        <polyline points="7 10 12 15 17 10"></polyline>
                                        <line x1="12" y1="15" x2="12" y2="3"></line>
                                    </svg>
                                    Exportar PDF
                                </button>
                            </div>
                        </div>
                        
                        <div class="report-preview">
                            <h3>Vista Previa del Reporte</h3>
                            <p class="report-count">Productos que coinciden: <span id="reportCount">0</span></p>
                            <div class="table-container">
                                <table class="products-table">
                                    <thead>
                                        <tr>
                                            <th>Nombre</th>
                                            <th>Categoría</th>
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Valor Total</th>
                                        </tr>
                                    </thead>
                                    <tbody id="reportPreviewBody">
                                        <tr>
                                            <td colspan="5" class="text-center">Selecciona filtros para ver la vista previa</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- User Modal -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="userModalTitle">Agregar Usuario</h3>
                <button onclick="closeUserModal()" class="modal-close">&times;</button>
            </div>
            <form id="userForm" onsubmit="handleUserSubmit(event)">
                <input type="hidden" id="userId">
                <div class="form-group">
                    <label for="userName">Nombre de Usuario</label>
                    <input type="text" id="userName" required>
                </div>
                <div class="form-group">
                    <label for="userPassword">Contraseña</label>
                    <input type="password" id="userPassword" required>
                    <small id="passwordHint" style="display: none;">Dejar en blanco para mantener la contraseña actual</small>
                </div>
                <div class="form-group">
                    <label for="userRole">Rol</label>
                    <select id="userRole" required class="select-input">
                        <option value="User">Usuario</option>
                        <option value="Admin">Administrador</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" onclick="closeUserModal()" class="btn-secondary">Cancelar</button>
                    <button type="submit" class="btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="js/admin.js"></script>
</body>
</html>
