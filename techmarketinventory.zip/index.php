<?php
require_once __DIR__ . '/config/auth.php';

$auth = new Auth();
if ($auth->isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechMarket - Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                        <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                        <line x1="12" y1="22.08" x2="12" y2="12"></line>
                    </svg>
                </div>
                <h1>TechMarket</h1>
                <p>Inicia sesión para gestionar tu inventario</p>
            </div>
            
            <form id="loginForm" class="login-form">
                <div class="form-group">
                    <label for="username">Usuario</label>
                    <input type="text" id="username" name="username" required placeholder="Ingresa tu usuario">
                </div>
                
                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <input type="password" id="password" name="password" required placeholder="Ingresa tu contraseña">
                </div>
                
                <div id="errorMessage" class="error-message" style="display: none;"></div>
                
                <button type="submit" class="btn-primary" id="loginBtn">
                    <span id="loginText">Iniciar Sesión</span>
                    <span id="loginLoader" class="loader" style="display: none;"></span>
                </button>
            </form>
            
            <div class="demo-credentials">
                <p class="demo-title">Credenciales de Prueba</p>
                <div class="credentials-list">
                    <div class="credential-item">
                        <span>Admin:</span>
                        <code>admin / admin123</code>
                    </div>
                    <div class="credential-item">
                        <span>Usuario:</span>
                        <code>user / user123</code>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="js/login.js"></script>
</body>
</html>
